# Human AI Health Platform - API Service

FastAPI backend service for medical document analysis using Amazon Bedrock.

## 🚀 Features

- **Document Processing**: Extract text from PDF, DOC, DOCX, TXT, and image files
- **Amazon Bedrock Integration**: AI-powered clinical risk assessment
- **OCR Support**: Text extraction from images using Tesseract
- **Mock Analysis**: Fallback analysis when Bedrock is not configured
- **RESTful API**: Well-documented endpoints with OpenAPI/Swagger
- **Configuration Management**: JSON-based configuration system

## 📋 Prerequisites

- Python 3.11+
- AWS Account with Bedrock access (optional for mock mode)
- Tesseract OCR (for image processing)

## 🛠️ Installation

### Local Development

1. **Create virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Install Tesseract** (for OCR):
   ```bash
   # Ubuntu/Debian
   sudo apt-get install tesseract-ocr tesseract-ocr-eng
   
   # macOS
   brew install tesseract
   
   # Windows
   # Download from: https://github.com/UB-Mannheim/tesseract/wiki
   ```

4. **Set environment variables**:
   ```bash
   export AWS_ACCESS_KEY_ID=your_access_key
   export AWS_SECRET_ACCESS_KEY=your_secret_key
   export AWS_DEFAULT_REGION=us-east-1
   export CONFIG_PATH=../../config/app-config.json
   ```

5. **Run the server**:
   ```bash
   python main.py
   # Or
   uvicorn main:app --reload --host 0.0.0.0 --port 8000
   ```

### Docker

```bash
# Build image
docker build -t health-platform-api .

# Run container
docker run -p 8000:8000 \
  -e AWS_ACCESS_KEY_ID=your_key \
  -e AWS_SECRET_ACCESS_KEY=your_secret \
  -e AWS_DEFAULT_REGION=us-east-1 \
  health-platform-api
```

## 📚 API Documentation

Once running, visit:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **OpenAPI JSON**: http://localhost:8000/openapi.json

## 🔧 Configuration

The API uses a JSON configuration file located at `../../config/app-config.json`. Key settings:

```json
{
  "aws": {
    "region": "us-east-1",
    "bedrock": {
      "model_id": "anthropic.claude-3-sonnet-20240229-v1:0",
      "max_tokens": 4000,
      "temperature": 0.1
    }
  },
  "upload": {
    "max_file_size_mb": 10,
    "allowed_extensions": [".pdf", ".txt", ".doc", ".docx", ".jpg", ".jpeg", ".png"]
  }
}
```

## 📡 API Endpoints

### Health Check
```http
GET /
GET /api/health
```

### Document Analysis
```http
POST /api/analyze-document
Content-Type: multipart/form-data

file: <uploaded_file>
```

**Response**:
```json
{
  "clinical_risks": [
    {
      "category": "Medication Interactions",
      "description": "Potential interaction detected",
      "severity": "High"
    }
  ],
  "care_plan_suggestions": [
    {
      "area": "Monitoring Schedule",
      "recommendation": "Monitor blood pressure daily",
      "priority": "Medium"
    }
  ],
  "summary": "Analysis summary"
}
```

### Configuration
```http
GET /api/config
```

## 🧪 Testing

### Manual Testing

```bash
# Health check
curl http://localhost:8000/api/health

# Upload document
curl -X POST "http://localhost:8000/api/analyze-document" \
     -H "accept: application/json" \
     -H "Content-Type: multipart/form-data" \
     -F "file=@sample.pdf"
```

### Python Testing

```python
import requests

# Test file upload
with open('sample.pdf', 'rb') as f:
    response = requests.post(
        'http://localhost:8000/api/analyze-document',
        files={'file': f}
    )
    print(response.json())
```

## 🔒 Security

- **File Validation**: Type and size restrictions
- **Input Sanitization**: All inputs are validated
- **Error Handling**: Sensitive information is not exposed
- **CORS**: Configurable origins

## 🐛 Troubleshooting

### Common Issues

1. **Import Errors**:
   ```bash
   # Ensure all dependencies are installed
   pip install -r requirements.txt
   ```

2. **AWS Credentials**:
   ```bash
   # Check credentials
   aws sts get-caller-identity
   ```

3. **Tesseract Not Found**:
   ```bash
   # Install Tesseract OCR
   sudo apt-get install tesseract-ocr
   ```

4. **Configuration File Not Found**:
   ```bash
   # Set correct path
   export CONFIG_PATH=/path/to/config/app-config.json
   ```

### Logs

The API provides detailed logging. Check console output for:
- Configuration loading status
- Bedrock client initialization
- Document processing steps
- Analysis results

## 🏗️ Architecture

```
services/
├── bedrock_client.py      # Amazon Bedrock integration
├── document_processor.py  # File processing and text extraction
└── config_manager.py     # Configuration management

main.py                   # FastAPI application and routes
```

### Key Components

1. **DocumentProcessor**: Handles text extraction from various file formats
2. **BedrockAnalyzer**: Manages AI analysis using Amazon Bedrock
3. **ConfigManager**: Loads and manages application configuration
4. **FastAPI App**: Provides REST API endpoints

## 🔄 Development

### Adding New File Types

1. Update `document_processor.py`:
   ```python
   async def _extract_from_new_format(self, file_content: bytes) -> str:
       # Implementation
       pass
   ```

2. Update configuration:
   ```json
   {
     "upload": {
       "allowed_extensions": [".pdf", ".new_format"]
     }
   }
   ```

### Customizing Analysis

1. Modify prompt in `bedrock_client.py`:
   ```python
   def _create_medical_analysis_prompt(self, document_text: str) -> str:
       # Custom prompt logic
   ```

2. Update response parsing:
   ```python
   def _parse_analysis_response(self, analysis_text: str) -> Dict[str, Any]:
       # Custom parsing logic
   ```

## 📦 Dependencies

- **FastAPI**: Web framework
- **Uvicorn**: ASGI server
- **Boto3**: AWS SDK
- **PyPDF2**: PDF processing
- **python-docx**: Word document processing
- **Pillow**: Image processing
- **pytesseract**: OCR functionality
- **python-multipart**: File upload support

## 🚀 Deployment

### Production Considerations

1. **Environment Variables**:
   ```bash
   export ENVIRONMENT=production
   export API_HOST=0.0.0.0
   export API_PORT=8000
   ```

2. **Process Management**:
   ```bash
   # Using Gunicorn
   gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker
   ```

3. **Reverse Proxy**:
   Configure Nginx or similar for production deployment.

4. **Health Monitoring**:
   Use `/api/health` endpoint for health checks.

## 📄 License

MIT License - see root README for details.
