import os
import json
import logging
from typing import List, Dict, Any
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from dotenv import load_dotenv

from services.document_processor import DocumentProcessor
from services.bedrock_client import BedrockAnalyzer
from services.config_manager import ConfigManager

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Human AI Health Platform API",
    description="Medical document analysis API using Amazon Bedrock",
    version="1.0.0"
)

# Initialize services
config_manager = ConfigManager()
document_processor = DocumentProcessor()
bedrock_analyzer = BedrockAnalyzer(config_manager)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=config_manager.get_cors_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Health check endpoint"""
    return {"message": "Human AI Health Platform API", "status": "healthy"}

@app.get("/api/health")
async def health_check():
    """Detailed health check"""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "services": {
            "document_processor": "ready",
            "bedrock_analyzer": "ready"
        }
    }

@app.post("/api/analyze-document")
async def analyze_document(file: UploadFile = File(...)):
    """
    Analyze uploaded medical document for clinical risks and care plan suggestions
    """
    try:
        # Validate file
        if not file.filename:
            raise HTTPException(status_code=400, detail="No file provided")
        
        # Check file size
        max_size = config_manager.get_max_file_size()
        if file.size and file.size > max_size:
            raise HTTPException(
                status_code=400, 
                detail=f"File size exceeds maximum allowed size of {max_size // (1024*1024)}MB"
            )
        
        # Check file extension
        allowed_extensions = config_manager.get_allowed_extensions()
        file_extension = os.path.splitext(file.filename)[1].lower()
        if file_extension not in allowed_extensions:
            raise HTTPException(
                status_code=400,
                detail=f"File type not supported. Allowed types: {', '.join(allowed_extensions)}"
            )
        
        logger.info(f"Processing file: {file.filename}")
        
        # Process document to extract text
        file_content = await file.read()
        extracted_text = await document_processor.extract_text(file_content, file.filename)
        
        if not extracted_text.strip():
            raise HTTPException(
                status_code=400,
                detail="Could not extract text from the document"
            )
        
        logger.info(f"Extracted {len(extracted_text)} characters from document")
        
        # Analyze with Bedrock
        analysis_result = await bedrock_analyzer.analyze_medical_document(extracted_text)
        
        logger.info("Document analysis completed successfully")
        
        return JSONResponse(content=analysis_result)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error analyzing document: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error during document analysis")

@app.get("/api/config")
async def get_config():
    """Get public configuration"""
    return {
        "max_file_size_mb": config_manager.get_max_file_size() // (1024 * 1024),
        "allowed_extensions": config_manager.get_allowed_extensions(),
        "clinical_risk_categories": config_manager.get_clinical_risk_categories(),
        "care_plan_areas": config_manager.get_care_plan_areas()
    }

if __name__ == "__main__":
    host = os.getenv("API_HOST", "0.0.0.0")
    port = int(os.getenv("API_PORT", "8000"))
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=True,
        log_level="info"
    )
