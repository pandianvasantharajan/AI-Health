import json
import boto3
import logging
import ssl
import urllib3
from typing import Dict, List, Any
from botocore.exceptions import ClientError, NoCredentialsError
from botocore.config import Config

# Disable SSL warnings for corporate networks
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

class BedrockAnalyzer:
    """Handles Amazon Bedrock integration for medical document analysis"""
    
    def __init__(self, config_manager):
        self.config_manager = config_manager
        self.bedrock_client = None
        self._initialize_bedrock_client()
    
    def _initialize_bedrock_client(self):
        """Initialize Bedrock client"""
        try:
            import os

            # Check if we have a custom Bedrock API key
            custom_api_key = os.environ.get('BEDROCK_API_KEY')
            if custom_api_key:
                logger.info("Using custom Bedrock API key authentication")
                # Store the custom key for later use in API calls
                self.custom_api_key = custom_api_key
                self.bedrock_client = "custom"  # Placeholder to indicate custom auth
                logger.info(f"Custom Bedrock client initialized for region: {self.config_manager.get_aws_region()}")
                return

            # Create config for AWS Bedrock
            config = Config(
                region_name=self.config_manager.get_aws_region(),
                retries={'max_attempts': 3},
                signature_version='v4'
            )

            # Handle SSL verification issues in corporate networks
            verify_ssl = True
            if os.environ.get('AWS_DISABLE_SSL_VERIFICATION', 'false').lower() == 'true':
                verify_ssl = False
                logger.warning("SSL verification disabled for AWS Bedrock client")

            self.bedrock_client = boto3.client(
                'bedrock-runtime',
                config=config,
                verify=verify_ssl
            )
            logger.info(f"Bedrock client initialized successfully for region: {self.config_manager.get_aws_region()}")
        except NoCredentialsError:
            logger.warning("AWS credentials not found. Bedrock client not initialized.")
            self.bedrock_client = None
        except Exception as e:
            logger.error(f"Error initializing Bedrock client: {str(e)}")
            self.bedrock_client = None
    
    async def analyze_medical_document(self, document_text: str) -> Dict[str, Any]:
        """
        Analyze medical document text using Amazon Bedrock
        """
        if not self.bedrock_client:
            logger.warning("Bedrock client not available, using mock analysis")
            return self._get_mock_analysis(document_text)

        # Check if using custom API key authentication
        if self.bedrock_client == "custom" and hasattr(self, 'custom_api_key'):
            return await self._analyze_with_custom_api(document_text)

        try:
            # Create the prompt for medical analysis
            prompt = self._create_medical_analysis_prompt(document_text)

            # Prepare the request body
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.config_manager.get_bedrock_max_tokens(),
                "temperature": self.config_manager.get_bedrock_temperature(),
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }

            # Call Bedrock
            response = self.bedrock_client.invoke_model(
                modelId=self.config_manager.get_bedrock_model_id(),
                body=json.dumps(request_body)
            )

            # Parse response
            response_body = json.loads(response['body'].read())
            analysis_text = response_body['content'][0]['text']

            # Parse the structured response
            return self._parse_analysis_response(analysis_text)

        except ClientError as e:
            logger.error(f"Bedrock API error: {str(e)}")
            return self._get_mock_analysis(document_text)
        except Exception as e:
            logger.error(f"Error during Bedrock analysis: {str(e)}")
            return self._get_mock_analysis(document_text)

    async def _analyze_with_custom_api(self, document_text: str) -> Dict[str, Any]:
        """
        Analyze document using custom API key authentication
        """
        try:
            import requests
            import base64
            import urllib.parse

            # Try to decode the custom API key safely
            try:
                # print('document_text',document_text)
                decoded_bytes = base64.b64decode(self.custom_api_key)
                decoded_url = decoded_bytes.decode('utf-8')

                logger.info(f"Decoded pre-signed URL (length: {len(decoded_url)})")

                # Check if this is a pre-signed AWS URL
                if 'bedrock.amazonaws.com' in decoded_url and 'X-Amz-Credential' in decoded_url:
                    logger.info("Detected AWS Bedrock pre-signed URL")
                    return await self._use_presigned_url(decoded_url, document_text)

                # Check if this looks like AWS credentials format (fallback)
                if ':' in decoded_url and len(decoded_url) < 200:  # Not a URL
                    parts = decoded_url.split(':', 1)
                    access_key_part = parts[0].strip()
                    secret_part = parts[1].strip() if len(parts) > 1 else ""

                    # Clean up any remaining control characters
                    access_key_part = ''.join(char for char in access_key_part if ord(char) >= 32)
                    secret_part = ''.join(char for char in secret_part if ord(char) >= 32)

                    logger.info(f"Detected credential format - Access key part: {access_key_part}")

                    if access_key_part and secret_part:
                        # Try to use these as AWS credentials
                        return await self._try_aws_credentials(access_key_part, secret_part, document_text)

            except Exception as decode_error:
                logger.warning(f"Could not decode API key: {decode_error}")
                # Use the raw key as-is
                decoded_url = self.custom_api_key

            # Create the prompt for medical analysis
            prompt = self._create_medical_analysis_prompt(document_text)

            # For now, we'll use enhanced mock analysis
            logger.info("Custom API key detected - using enhanced mock analysis")

            # Enhanced mock analysis with custom key indication
            result = self._get_mock_analysis(document_text)
            result["summary"] = f"Enhanced analysis using custom authentication. {result.get('summary', '')}"

            return result

        except Exception as e:
            logger.error(f"Error with custom API authentication: {str(e)}")
            return self._get_mock_analysis(document_text)

    async def _use_presigned_url(self, presigned_url: str, document_text: str) -> Dict[str, Any]:
        """
        Use pre-signed URL to make direct HTTP request to Bedrock API
        """
        try:
            import requests
            import urllib.parse

            logger.info("Attempting to use pre-signed URL for Bedrock API call")

            # Parse the URL to extract credentials for logging
            parsed_url = urllib.parse.urlparse(f"https://{presigned_url}")
            query_params = urllib.parse.parse_qs(parsed_url.query)

            # Extract access key for logging
            credential = query_params.get('X-Amz-Credential', [None])[0]
            if credential:
                access_key = credential.split('/')[0] if '/' in credential else credential
                logger.info(f"Extracted credentials from pre-signed URL - Access Key: {access_key}")

            # Check if this is a CallWithBearerToken URL (not standard Bedrock model invocation)
            if 'Action=CallWithBearerToken' in presigned_url:
                logger.info("Detected CallWithBearerToken URL - attempting direct API call")
                return await self._call_with_bearer_token(presigned_url, document_text)
            else:
                # Try to construct a proper Bedrock model invocation URL
                logger.info("Attempting to construct Bedrock model invocation URL")
                return await self._call_bedrock_model_direct(presigned_url, document_text)

        except Exception as e:
            logger.error(f"Error processing pre-signed URL: {str(e)}")
            return self._get_enhanced_mock_analysis(document_text)

    async def _call_with_bearer_token(self, presigned_url: str, document_text: str) -> Dict[str, Any]:
        """
        Handle CallWithBearerToken URL format
        """
        try:
            import requests
            import urllib.parse

            # Create the prompt for medical analysis
            prompt = self._create_medical_analysis_prompt(document_text)

            # Prepare the request body for Bedrock
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.config_manager.get_bedrock_max_tokens(),
                "temperature": self.config_manager.get_bedrock_temperature(),
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }

            # Fix the hostname in the pre-signed URL
            # Replace bedrock.amazonaws.com with bedrock-runtime.{region}.amazonaws.com
            region = self.config_manager.get_aws_region()
            corrected_url = presigned_url.replace(
                'bedrock.amazonaws.com',
                f'bedrock-runtime.{region}.amazonaws.com'
            )

            # The pre-signed URL is designed to be used as-is, but we need to modify it for the correct endpoint
            # Parse the original URL to get the query parameters
            parsed_url = urllib.parse.urlparse(f"https://{corrected_url}")

            # Build the final URL for model invocation using the pre-signed URL approach
            model_id = self.config_manager.get_bedrock_model_id()
            encoded_model_id = urllib.parse.quote(model_id, safe='')

            # Use the pre-signed URL directly but modify the path for model invocation
            final_url = f"https://bedrock-runtime.{region}.amazonaws.com/model/{encoded_model_id}/invoke?{parsed_url.query}"

            # For pre-signed URLs, we don't need to add authorization headers
            # The authentication is embedded in the URL parameters
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }

            # Handle SSL verification based on environment setting
            import os
            verify_ssl = not (os.environ.get('AWS_DISABLE_SSL_VERIFICATION', 'false').lower() == 'true')

            logger.info(f"Making direct HTTP request to Bedrock runtime endpoint: bedrock-runtime.{region}.amazonaws.com (SSL verify: {verify_ssl})")
            response = requests.post(
                final_url,
                json=request_body,
                headers=headers,
                timeout=30,
                verify=verify_ssl
            )

            logger.info(f"Response status: {response.status_code}")

            if response.status_code == 200:
                response_data = response.json()

                # Check if response has the expected Bedrock format
                if 'content' in response_data and len(response_data['content']) > 0:
                    analysis_text = response_data['content'][0]['text']
                    logger.info("Successfully received response from Bedrock via pre-signed URL")
                    return self._parse_analysis_response(analysis_text)
                else:
                    logger.warning(f"Unexpected response format: {response_data}")
                    return self._get_enhanced_mock_analysis(document_text)
            else:
                logger.error(f"Bedrock API returned status {response.status_code}: {response.text}")
                return self._get_enhanced_mock_analysis(document_text)

        except Exception as e:
            logger.error(f"Error calling with bearer token: {str(e)}")
            return self._get_enhanced_mock_analysis(document_text)

    async def _call_bedrock_model_direct(self, presigned_url: str, document_text: str) -> Dict[str, Any]:
        """
        Attempt to call Bedrock model directly using modified pre-signed URL
        """
        try:
            import requests
            import urllib.parse

            # Create the prompt for medical analysis
            prompt = self._create_medical_analysis_prompt(document_text)

            # Prepare the request body for Bedrock
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.config_manager.get_bedrock_max_tokens(),
                "temperature": self.config_manager.get_bedrock_temperature(),
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }

            # Parse the base URL and modify it for model invocation
            parsed_url = urllib.parse.urlparse(f"https://{presigned_url}")

            # Construct Bedrock runtime endpoint
            base_host = "bedrock-runtime.us-west-2.amazonaws.com"
            model_id = self.config_manager.get_bedrock_model_id()
            encoded_model_id = urllib.parse.quote(model_id, safe='')

            # Build the model invocation URL with the same query parameters
            model_url = f"https://{base_host}/model/{encoded_model_id}/invoke?{parsed_url.query}"

            # Make the HTTP POST request
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }

            # Handle SSL verification based on environment setting
            import os
            verify_ssl = not (os.environ.get('AWS_DISABLE_SSL_VERIFICATION', 'false').lower() == 'true')

            logger.info(f"Making direct HTTP request to Bedrock model endpoint (SSL verify: {verify_ssl})")
            response = requests.post(
                model_url,
                json=request_body,
                headers=headers,
                timeout=30,
                verify=verify_ssl
            )

            logger.info(f"Response status: {response.status_code}")

            if response.status_code == 200:
                response_data = response.json()
                analysis_text = response_data['content'][0]['text']
                logger.info("Successfully received response from Bedrock model endpoint")
                return self._parse_analysis_response(analysis_text)
            else:
                logger.error(f"Bedrock model API returned status {response.status_code}: {response.text}")
                return self._get_enhanced_mock_analysis(document_text)

        except Exception as e:
            logger.error(f"Error calling Bedrock model directly: {str(e)}")
            return self._get_enhanced_mock_analysis(document_text)

    async def _try_aws_credentials_with_token(self, access_key: str, session_token: str, document_text: str) -> Dict[str, Any]:
        """
        Try to use extracted credentials with session token for AWS Bedrock
        """
        try:
            import os

            # Temporarily set credentials
            original_access_key = os.environ.get('AWS_ACCESS_KEY_ID')
            original_secret_key = os.environ.get('AWS_SECRET_ACCESS_KEY')
            original_session_token = os.environ.get('AWS_SESSION_TOKEN')

            os.environ['AWS_ACCESS_KEY_ID'] = access_key
            # We need the secret key - for now, try with existing one or use a placeholder
            if not os.environ.get('AWS_SECRET_ACCESS_KEY'):
                logger.warning("No secret key available, using enhanced mock analysis")
                return self._get_enhanced_mock_analysis(document_text)

            os.environ['AWS_SESSION_TOKEN'] = session_token

            # Create a new boto3 client with these credentials
            config = Config(
                region_name=self.config_manager.get_aws_region(),
                retries={'max_attempts': 3},
                signature_version='v4'
            )

            verify_ssl = not (os.environ.get('AWS_DISABLE_SSL_VERIFICATION', 'false').lower() == 'true')

            temp_client = boto3.client(
                'bedrock-runtime',
                config=config,
                verify=verify_ssl
            )

            # Create the prompt for medical analysis
            prompt = self._create_medical_analysis_prompt(document_text)

            # Prepare the request body
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.config_manager.get_bedrock_max_tokens(),
                "temperature": self.config_manager.get_bedrock_temperature(),
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }

            # Call Bedrock
            response = temp_client.invoke_model(
                modelId=self.config_manager.get_bedrock_model_id(),
                body=json.dumps(request_body)
            )

            # Parse response
            response_body = json.loads(response['body'].read())
            analysis_text = response_body['content'][0]['text']

            logger.info("Successfully used pre-signed URL credentials for Bedrock analysis")

            # Restore original credentials
            if original_access_key:
                os.environ['AWS_ACCESS_KEY_ID'] = original_access_key
            else:
                os.environ.pop('AWS_ACCESS_KEY_ID', None)

            if original_secret_key:
                os.environ['AWS_SECRET_ACCESS_KEY'] = original_secret_key
            else:
                os.environ.pop('AWS_SECRET_ACCESS_KEY', None)

            if original_session_token:
                os.environ['AWS_SESSION_TOKEN'] = original_session_token
            else:
                os.environ.pop('AWS_SESSION_TOKEN', None)

            # Parse the structured response
            return self._parse_analysis_response(analysis_text)

        except Exception as e:
            logger.error(f"Failed to use pre-signed URL credentials: {str(e)}")
            # Restore original credentials on error
            if 'original_access_key' in locals() and original_access_key:
                os.environ['AWS_ACCESS_KEY_ID'] = original_access_key
            else:
                os.environ.pop('AWS_ACCESS_KEY_ID', None)

            if 'original_secret_key' in locals() and original_secret_key:
                os.environ['AWS_SECRET_ACCESS_KEY'] = original_secret_key
            else:
                os.environ.pop('AWS_SECRET_ACCESS_KEY', None)

            if 'original_session_token' in locals() and original_session_token:
                os.environ['AWS_SESSION_TOKEN'] = original_session_token
            else:
                os.environ.pop('AWS_SESSION_TOKEN', None)

            return self._get_enhanced_mock_analysis(document_text)

    def _get_enhanced_mock_analysis(self, document_text: str) -> Dict[str, Any]:
        """
        Enhanced mock analysis with better detection
        """
        result = self._get_mock_analysis(document_text)
        result["summary"] = f"Enhanced analysis using pre-signed URL authentication. {result.get('summary', '')}"
        return result

    async def _try_aws_credentials(self, access_key: str, secret_key: str, document_text: str) -> Dict[str, Any]:
        """
        Try to use extracted credentials for AWS Bedrock
        """
        try:
            import os

            # Temporarily set credentials
            original_access_key = os.environ.get('AWS_ACCESS_KEY_ID')
            original_secret_key = os.environ.get('AWS_SECRET_ACCESS_KEY')

            os.environ['AWS_ACCESS_KEY_ID'] = access_key
            os.environ['AWS_SECRET_ACCESS_KEY'] = secret_key

            # Create a new boto3 client with these credentials
            config = Config(
                region_name=self.config_manager.get_aws_region(),
                retries={'max_attempts': 3},
                signature_version='v4'
            )

            verify_ssl = not (os.environ.get('AWS_DISABLE_SSL_VERIFICATION', 'false').lower() == 'true')

            temp_client = boto3.client(
                'bedrock-runtime',
                config=config,
                verify=verify_ssl
            )

            # Create the prompt for medical analysis
            prompt = self._create_medical_analysis_prompt(document_text)

            # Prepare the request body
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.config_manager.get_bedrock_max_tokens(),
                "temperature": self.config_manager.get_bedrock_temperature(),
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }

            # Call Bedrock
            response = temp_client.invoke_model(
                modelId=self.config_manager.get_bedrock_model_id(),
                body=json.dumps(request_body)
            )

            # Parse response
            response_body = json.loads(response['body'].read())
            analysis_text = response_body['content'][0]['text']

            logger.info("Successfully used custom credentials for Bedrock analysis")

            # Restore original credentials
            if original_access_key:
                os.environ['AWS_ACCESS_KEY_ID'] = original_access_key
            else:
                os.environ.pop('AWS_ACCESS_KEY_ID', None)

            if original_secret_key:
                os.environ['AWS_SECRET_ACCESS_KEY'] = original_secret_key
            else:
                os.environ.pop('AWS_SECRET_ACCESS_KEY', None)

            # Parse the structured response
            return self._parse_analysis_response(analysis_text)

        except Exception as e:
            logger.error(f"Failed to use custom credentials: {str(e)}")
            # Restore original credentials on error
            if 'original_access_key' in locals() and original_access_key:
                os.environ['AWS_ACCESS_KEY_ID'] = original_access_key
            else:
                os.environ.pop('AWS_ACCESS_KEY_ID', None)

            if 'original_secret_key' in locals() and original_secret_key:
                os.environ['AWS_SECRET_ACCESS_KEY'] = original_secret_key
            else:
                os.environ.pop('AWS_SECRET_ACCESS_KEY', None)

            return self._get_mock_analysis(document_text)

    def _create_medical_analysis_prompt(self, document_text: str) -> str:
        """Create a structured prompt for medical document analysis"""
        
        risk_categories = self.config_manager.get_clinical_risk_categories()
        care_areas = self.config_manager.get_care_plan_areas()
        
        prompt = f"""
You are a clinical AI assistant analyzing medical documents. Please analyze the following medical document and provide a structured assessment.

MEDICAL DOCUMENT:
{document_text}

Please provide your analysis in the following JSON format:

{{
    "clinical_risks": [
        {{
            "category": "Risk Category",
            "description": "Detailed description of the risk",
            "severity": "High|Medium|Low"
        }}
    ],
    "care_plan_suggestions": [
        {{
            "area": "Care Area",
            "recommendation": "Specific recommendation",
            "priority": "High|Medium|Low"
        }}
    ],
    "summary": "Brief overall summary of findings"
}}

Focus on identifying:

CLINICAL RISKS (choose from these categories when applicable):
{', '.join(risk_categories)}

CARE PLAN AREAS (choose from these areas when applicable):
{', '.join(care_areas)}

Guidelines:
- Only identify risks that are clearly indicated in the document
- Provide specific, actionable care plan suggestions
- Use clinical terminology appropriately
- Assign appropriate severity/priority levels
- If no significant risks are found, indicate this clearly
- Ensure all recommendations are evidence-based

Respond ONLY with the JSON format requested above.
"""
        return prompt
    
    def _parse_analysis_response(self, analysis_text: str) -> Dict[str, Any]:
        """Parse the structured response from Bedrock"""
        try:
            # Try to extract JSON from the response
            start_idx = analysis_text.find('{')
            end_idx = analysis_text.rfind('}') + 1
            
            if start_idx != -1 and end_idx != -1:
                json_str = analysis_text[start_idx:end_idx]
                return json.loads(json_str)
            else:
                # If no JSON found, create a structured response from the text
                return {
                    "clinical_risks": [
                        {
                            "category": "Analysis Result",
                            "description": analysis_text[:500] + "..." if len(analysis_text) > 500 else analysis_text,
                            "severity": "Medium"
                        }
                    ],
                    "care_plan_suggestions": [
                        {
                            "area": "General Care",
                            "recommendation": "Please review the analysis with a healthcare professional",
                            "priority": "Medium"
                        }
                    ],
                    "summary": "Analysis completed. Please review findings with healthcare provider."
                }
        except json.JSONDecodeError:
            logger.error("Failed to parse JSON response from Bedrock")
            return self._get_mock_analysis(analysis_text[:200])
    
    def _get_mock_analysis(self, document_text: str) -> Dict[str, Any]:
        """Provide mock analysis when Bedrock is not available"""
        logger.info("Providing mock analysis (Bedrock not available)")
        
        # Simple keyword-based mock analysis
        text_lower = document_text.lower()
        
        risks = []
        suggestions = []
        
        # Mock risk detection based on keywords
        if any(word in text_lower for word in ['allergy', 'allergic', 'reaction']):
            risks.append({
                "category": "Allergic Reactions",
                "description": "Document mentions allergies or allergic reactions. Verify patient allergy status.",
                "severity": "High"
            })
        
        if any(word in text_lower for word in ['medication', 'drug', 'prescription', 'dose']):
            risks.append({
                "category": "Medication Management",
                "description": "Medication mentioned in document. Review for interactions and proper dosing.",
                "severity": "Medium"
            })
        
        if any(word in text_lower for word in ['blood pressure', 'hypertension', 'bp']):
            suggestions.append({
                "area": "Monitoring Schedule",
                "recommendation": "Regular blood pressure monitoring recommended",
                "priority": "Medium"
            })
        
        if any(word in text_lower for word in ['diabetes', 'blood sugar', 'glucose']):
            suggestions.append({
                "area": "Patient Education",
                "recommendation": "Diabetes management education and glucose monitoring",
                "priority": "High"
            })
        
        # Default suggestions if none found
        if not risks:
            risks.append({
                "category": "General Assessment",
                "description": "Document processed successfully. No specific risks identified in this analysis.",
                "severity": "Low"
            })
        
        if not suggestions:
            suggestions.append({
                "area": "Follow-up Care",
                "recommendation": "Schedule regular follow-up appointment with healthcare provider",
                "priority": "Medium"
            })
        
        return {
            "clinical_risks": risks,
            "care_plan_suggestions": suggestions,
            "summary": f"Mock analysis completed for document containing {len(document_text)} characters. This is a demonstration - please configure AWS Bedrock for full AI analysis."
        }
