import json
import os
from typing import List, Dict, Any

class ConfigManager:
    """Manages application configuration from JSON file"""
    
    def __init__(self, config_path: str = None):
        if config_path is None:
            config_path = os.getenv("CONFIG_PATH", "../../config/app-config.json")
        
        self.config_path = config_path
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        try:
            # Try relative path first
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r') as f:
                    return json.load(f)
            
            # Try absolute path
            abs_path = os.path.abspath(self.config_path)
            if os.path.exists(abs_path):
                with open(abs_path, 'r') as f:
                    return json.load(f)
            
            # Try from project root
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            root_config_path = os.path.join(project_root, "config", "app-config.json")
            if os.path.exists(root_config_path):
                with open(root_config_path, 'r') as f:
                    return json.load(f)
            
            # Return default config if file not found
            return self._get_default_config()
            
        except Exception as e:
            print(f"Warning: Could not load config from {self.config_path}: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Return default configuration"""
        return {
            "api": {
                "cors_origins": ["http://localhost:3000", "http://localhost:5173"]
            },
            "aws": {
                "region": "us-east-1",
                "bedrock": {
                    "model_id": "anthropic.claude-3-sonnet-20240229-v1:0",
                    "max_tokens": 4000,
                    "temperature": 0.1
                }
            },
            "upload": {
                "max_file_size_mb": 10,
                "allowed_extensions": [".pdf", ".txt", ".doc", ".docx", ".jpg", ".jpeg", ".png"]
            },
            "analysis": {
                "clinical_risk_categories": [
                    "Medication Interactions",
                    "Allergic Reactions", 
                    "Dosage Concerns",
                    "Contraindications",
                    "Monitoring Requirements",
                    "Patient Safety",
                    "Treatment Compliance"
                ],
                "care_plan_areas": [
                    "Medication Management",
                    "Monitoring Schedule",
                    "Patient Education",
                    "Follow-up Care",
                    "Emergency Protocols",
                    "Lifestyle Modifications"
                ]
            }
        }
    
    def get_cors_origins(self) -> List[str]:
        """Get CORS origins"""
        return self.config.get("api", {}).get("cors_origins", ["*"])
    
    def get_aws_region(self) -> str:
        """Get AWS region"""
        import os
        # Check environment variable first, then config file, then default
        return os.environ.get('AWS_DEFAULT_REGION') or self.config.get("aws", {}).get("region", "us-east-1")
    
    def get_bedrock_model_id(self) -> str:
        """Get Bedrock model ID"""
        return self.config.get("aws", {}).get("bedrock", {}).get("model_id", "anthropic.claude-3-sonnet-20240229-v1:0")
    
    def get_bedrock_max_tokens(self) -> int:
        """Get Bedrock max tokens"""
        return self.config.get("aws", {}).get("bedrock", {}).get("max_tokens", 4000)
    
    def get_bedrock_temperature(self) -> float:
        """Get Bedrock temperature"""
        return self.config.get("aws", {}).get("bedrock", {}).get("temperature", 0.1)
    
    def get_max_file_size(self) -> int:
        """Get max file size in bytes"""
        size_mb = self.config.get("upload", {}).get("max_file_size_mb", 10)
        return size_mb * 1024 * 1024
    
    def get_allowed_extensions(self) -> List[str]:
        """Get allowed file extensions"""
        return self.config.get("upload", {}).get("allowed_extensions", [".pdf", ".txt"])
    
    def get_clinical_risk_categories(self) -> List[str]:
        """Get clinical risk categories"""
        return self.config.get("analysis", {}).get("clinical_risk_categories", [])
    
    def get_care_plan_areas(self) -> List[str]:
        """Get care plan areas"""
        return self.config.get("analysis", {}).get("care_plan_areas", [])
