import io
import os
import tempfile
from typing import Optional
import PyPDF2
from docx import Document
from PIL import Image
import pytesseract

class DocumentProcessor:
    """Handles document text extraction from various file formats"""
    
    def __init__(self):
        pass
    
    async def extract_text(self, file_content: bytes, filename: str) -> str:
        """
        Extract text from uploaded file based on file type
        """
        file_extension = os.path.splitext(filename)[1].lower()
        
        try:
            if file_extension == '.pdf':
                return await self._extract_from_pdf(file_content)
            elif file_extension in ['.doc', '.docx']:
                return await self._extract_from_docx(file_content)
            elif file_extension == '.txt':
                return await self._extract_from_txt(file_content)
            elif file_extension in ['.jpg', '.jpeg', '.png']:
                return await self._extract_from_image(file_content)
            else:
                raise ValueError(f"Unsupported file type: {file_extension}")
                
        except Exception as e:
            raise Exception(f"Error extracting text from {filename}: {str(e)}")
    
    async def _extract_from_pdf(self, file_content: bytes) -> str:
        """Extract text from PDF file"""
        try:
            pdf_file = io.BytesIO(file_content)
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            
            return text.strip()
        except Exception as e:
            raise Exception(f"Error reading PDF: {str(e)}")
    
    async def _extract_from_docx(self, file_content: bytes) -> str:
        """Extract text from DOCX file"""
        try:
            doc_file = io.BytesIO(file_content)
            doc = Document(doc_file)
            
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            
            return text.strip()
        except Exception as e:
            raise Exception(f"Error reading DOCX: {str(e)}")
    
    async def _extract_from_txt(self, file_content: bytes) -> str:
        """Extract text from TXT file"""
        try:
            return file_content.decode('utf-8').strip()
        except UnicodeDecodeError:
            try:
                return file_content.decode('latin-1').strip()
            except Exception as e:
                raise Exception(f"Error reading text file: {str(e)}")
    
    async def _extract_from_image(self, file_content: bytes) -> str:
        """Extract text from image using OCR"""
        try:
            # Create a temporary file for the image
            with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as temp_file:
                temp_file.write(file_content)
                temp_file_path = temp_file.name
            
            try:
                # Open image and perform OCR
                image = Image.open(temp_file_path)
                text = pytesseract.image_to_string(image)
                return text.strip()
            finally:
                # Clean up temporary file
                os.unlink(temp_file_path)
                
        except Exception as e:
            # If OCR fails, try to return a helpful message
            return f"OCR extraction failed: {str(e)}. Please ensure the image contains clear, readable text."
