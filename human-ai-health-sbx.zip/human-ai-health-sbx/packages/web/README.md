# Human AI Health Platform - Web Application

React frontend for medical document analysis with modern UI and drag-and-drop file upload.

## 🚀 Features

- **Modern React UI**: Built with React 18 and Vite
- **Drag & Drop Upload**: Intuitive file upload interface
- **Real-time Analysis**: Live updates during document processing
- **Responsive Design**: Works on desktop and mobile devices
- **File Type Support**: PDF, DOC, DOCX, TXT, JPG, PNG
- **Progress Indicators**: Loading states and progress feedback
- **Error Handling**: User-friendly error messages
- **Professional Styling**: Healthcare-focused design

## 📋 Prerequisites

- Node.js 18+
- npm or yarn

## 🛠️ Installation

### Local Development

1. **Install dependencies**:

   ```bash
   npm install
   ```

2. **Set environment variables**:

   ```bash
   # Create .env.local file
   VITE_API_BASE_URL=http://localhost:8000
   ```

3. **Start development server**:

   ```bash
   npm run dev
   ```

4. **Open browser**:
   Visit http://localhost:5173

### Production Build

```bash
# Build for production
npm run build

# Preview production build
npm run preview
```

### Docker

```bash
# Build image
docker build -t health-platform-web .

# Run container
docker run -p 3000:3000 health-platform-web
```

## 🏗️ Project Structure

```
src/
├── components/
│   ├── Header.jsx           # Application header
│   ├── DocumentUpload.jsx   # File upload component
│   └── AnalysisResults.jsx  # Results display component
├── App.jsx                  # Main application component
├── App.css                  # Application styles
└── main.jsx                 # Application entry point
```

## 🎨 Components

### Header

- Displays application title and branding
- Responsive navigation

### DocumentUpload

- Drag-and-drop file upload
- File validation and preview
- Upload progress indication
- Integration with API service

### AnalysisResults

- Displays clinical risks
- Shows care plan suggestions
- Formatted results with icons
- Error state handling

## 🔧 Configuration

### Environment Variables

```bash
# API Configuration
VITE_API_BASE_URL=http://localhost:8000

# Development
VITE_NODE_ENV=development
```

### Vite Configuration

The application uses Vite for fast development and building:

```javascript
// vite.config.js
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
  },
  preview: {
    host: '0.0.0.0',
    port: 3000,
  },
});
```

## 📱 User Interface

### Upload Flow

1. **File Selection**: Drag & drop or click to select file
2. **File Validation**: Automatic validation of file type and size
3. **File Preview**: Display selected file information
4. **Analysis Trigger**: Click "Analyze with AI" button
5. **Loading State**: Show progress indicator
6. **Results Display**: Show analysis results

### Supported File Types

- **Documents**: PDF, DOC, DOCX, TXT
- **Images**: JPG, JPEG, PNG
- **Size Limit**: 10MB maximum

### UI States

- **Empty State**: Initial upload interface
- **File Selected**: File preview with analyze button
- **Loading State**: Progress indicator during analysis
- **Results State**: Display analysis results
- **Error State**: Error message display

## 🎨 Styling

The application uses modern CSS with:

- **CSS Grid & Flexbox**: Responsive layouts
- **CSS Variables**: Consistent theming
- **Animations**: Smooth transitions
- **Responsive Design**: Mobile-first approach
- **Healthcare Theme**: Professional color scheme

### Color Palette

```css
:root {
  --primary: #667eea;
  --secondary: #764ba2;
  --success: #38a169;
  --warning: #dd6b20;
  --error: #e53e3e;
  --text-primary: #2d3748;
  --text-secondary: #718096;
  --background: #f7fafc;
}
```

## 🔌 API Integration

### Axios Configuration

```javascript
const apiBaseUrl = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

// File upload
const response = await axios.post(
  `${apiBaseUrl}/api/analyze-document`,
  formData,
  {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  }
);
```

### Error Handling

```javascript
try {
  const response = await axios.post(endpoint, data);
  onAnalysisComplete(response.data);
} catch (error) {
  console.error('Analysis failed:', error);
  onAnalysisComplete({
    error: 'Failed to analyze document. Please try again.',
    clinical_risks: [],
    care_plan_suggestions: [],
  });
}
```

## 📄 License

MIT License - see root README for details.
