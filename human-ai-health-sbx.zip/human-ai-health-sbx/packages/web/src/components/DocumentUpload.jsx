import { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText, Loader2, Brain } from 'lucide-react';
import axios from 'axios';

const DocumentUpload = ({ onAnalysisStart, onAnalysisComplete, isLoading }) => {
  const [selectedFile, setSelectedFile] = useState(null);

  const onDrop = (acceptedFiles) => {
    if (acceptedFiles.length > 0) {
      setSelectedFile(acceptedFiles[0]);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
        ['.docx'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
    },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024, // 10MB
  });

  const handleAnalyze = async () => {
    if (!selectedFile) return;

    onAnalysisStart();

    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      const apiBaseUrl =
        import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
      const response = await axios.post(
        `${apiBaseUrl}/api/analyze-document`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      onAnalysisComplete(response.data, selectedFile.name);
    } catch (error) {
      console.error('Analysis failed:', error);
      onAnalysisComplete(
        {
          error: 'Failed to analyze document. Please try again.',
          clinical_risks: [],
          care_plan_suggestions: [],
        },
        selectedFile.name
      );
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className='upload-container'>
      <h2 className='upload-title'>Medical Document Analysis</h2>
      <p className='upload-subtitle'>
        Upload doctor prescriptions or medical notes to get clinical risk
        assessment and care plan suggestions
      </p>

      <div
        {...getRootProps()}
        className={`dropzone ${isDragActive ? 'active' : ''}`}
      >
        <input {...getInputProps()} />
        <div className='dropzone-content'>
          <Upload size={48} className='upload-icon' />
          <div className='dropzone-text'>
            {isDragActive
              ? 'Drop the file here...'
              : 'Drag & drop a medical document here'}
          </div>
          <div className='dropzone-subtext'>
            or click to select a file (PDF, DOC, DOCX, TXT, JPG, PNG - max 10MB)
          </div>
        </div>
      </div>

      {selectedFile && (
        <div className='file-info'>
          <FileText size={24} className='file-icon' />
          <div className='file-details'>
            <h4>{selectedFile.name}</h4>
            <p>
              {formatFileSize(selectedFile.size)} •{' '}
              {selectedFile.type || 'Unknown type'}
            </p>
          </div>
        </div>
      )}

      {selectedFile && (
        <button
          onClick={handleAnalyze}
          disabled={isLoading}
          className='analyze-button'
        >
          {isLoading ? (
            <>
              <Loader2 size={20} className='loading-spinner' />
              Analyzing Document...
            </>
          ) : (
            <>
              <Brain size={20} />
              Analyze with AI
            </>
          )}
        </button>
      )}
    </div>
  );
};

export default DocumentUpload;
