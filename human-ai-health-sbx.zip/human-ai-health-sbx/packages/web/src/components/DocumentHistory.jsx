import { History, CheckCircle, XCircle, Clock, Trash2 } from 'lucide-react';

const DocumentHistory = ({ documents, activeDocumentId, onDocumentClick, onClearHistory }) => {
  const formatDate = (date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success':
        return <CheckCircle size={14} className="status-success" />;
      case 'error':
        return <XCircle size={14} className="status-error" />;
      case 'processing':
        return <Clock size={14} className="status-processing" />;
      default:
        return <Clock size={14} className="status-processing" />;
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'success':
        return 'Analysis Complete';
      case 'error':
        return 'Analysis Failed';
      case 'processing':
        return 'Processing...';
      default:
        return 'Unknown';
    }
  };

  const getSummaryText = (results) => {
    if (results.error) {
      return results.error;
    }
    
    const riskCount = results.clinical_risks?.length || 0;
    const suggestionCount = results.care_plan_suggestions?.length || 0;
    
    return `${riskCount} risk${riskCount !== 1 ? 's' : ''} identified, ${suggestionCount} suggestion${suggestionCount !== 1 ? 's' : ''}`;
  };

  return (
    <div className="history-panel">
      <div className="history-title">
        <History className="history-icon" />
        Document History
      </div>
      
      {documents.length === 0 ? (
        <div className="empty-history">
          No documents analyzed yet. Upload a document to get started.
        </div>
      ) : (
        <>
          <div className="history-list">
            {documents.map((document) => (
              <div
                key={document.id}
                className={`history-item ${activeDocumentId === document.id ? 'active' : ''}`}
                onClick={() => onDocumentClick(document)}
              >
                <div className="history-item-header">
                  <div className="history-item-name" title={document.fileName}>
                    {document.fileName}
                  </div>
                  <div className="history-item-date">
                    {formatDate(document.timestamp)}
                  </div>
                </div>
                
                <div className="history-item-status">
                  {getStatusIcon(document.status)}
                  <span>{getStatusText(document.status)}</span>
                </div>
                
                <div className="history-item-summary">
                  {getSummaryText(document.results)}
                </div>
              </div>
            ))}
          </div>
          
          <button
            onClick={onClearHistory}
            className="clear-history-btn"
            disabled={documents.length === 0}
          >
            <Trash2 size={14} style={{ marginRight: '0.5rem' }} />
            Clear History
          </button>
        </>
      )}
    </div>
  );
};

export default DocumentHistory;
