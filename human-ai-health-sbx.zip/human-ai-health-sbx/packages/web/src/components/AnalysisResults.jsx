import { AlertTriangle, Heart, CheckCircle } from 'lucide-react';

const AnalysisResults = ({ results }) => {
  if (results.error) {
    return (
      <div className="results-container">
        <div className="results-title">
          <AlertTriangle className="results-icon" />
          Analysis Error
        </div>
        <p style={{ color: '#e53e3e' }}>{results.error}</p>
      </div>
    );
  }

  return (
    <div className="results-container">
      <div className="results-title">
        <CheckCircle className="results-icon" />
        Analysis Results
      </div>

      <div className="results-grid">
        <div className="risk-section">
          <div className="section-title">
            <AlertTriangle className="risk-icon" />
            Clinical Risks Identified
          </div>
          {results.clinical_risks && results.clinical_risks.length > 0 ? (
            results.clinical_risks.map((risk, index) => (
              <div key={index} className="risk-item">
                <div className="item-title">{risk.category || `Risk ${index + 1}`}</div>
                <div className="item-description">{risk.description || risk}</div>
                {risk.severity && (
                  <div style={{ 
                    marginTop: '0.5rem', 
                    fontSize: '0.8rem', 
                    fontWeight: 'bold',
                    color: risk.severity === 'High' ? '#e53e3e' : 
                           risk.severity === 'Medium' ? '#dd6b20' : '#38a169'
                  }}>
                    Severity: {risk.severity}
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="risk-item">
              <div className="item-description">No significant clinical risks identified.</div>
            </div>
          )}
        </div>

        <div className="care-plan-section">
          <div className="section-title">
            <Heart className="care-icon" />
            Care Plan Suggestions
          </div>
          {results.care_plan_suggestions && results.care_plan_suggestions.length > 0 ? (
            results.care_plan_suggestions.map((suggestion, index) => (
              <div key={index} className="care-item">
                <div className="item-title">{suggestion.area || `Suggestion ${index + 1}`}</div>
                <div className="item-description">{suggestion.recommendation || suggestion}</div>
                {suggestion.priority && (
                  <div style={{ 
                    marginTop: '0.5rem', 
                    fontSize: '0.8rem', 
                    fontWeight: 'bold',
                    color: suggestion.priority === 'High' ? '#e53e3e' : 
                           suggestion.priority === 'Medium' ? '#dd6b20' : '#38a169'
                  }}>
                    Priority: {suggestion.priority}
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="care-item">
              <div className="item-description">No specific care plan suggestions at this time.</div>
            </div>
          )}
        </div>
      </div>

      {results.summary && (
        <div style={{ 
          marginTop: '2rem', 
          padding: '1rem', 
          background: '#f7fafc', 
          borderRadius: '8px',
          borderLeft: '4px solid #667eea'
        }}>
          <div style={{ fontWeight: 'bold', marginBottom: '0.5rem', color: '#2d3748' }}>
            Summary
          </div>
          <div style={{ color: '#718096', lineHeight: '1.5' }}>
            {results.summary}
          </div>
        </div>
      )}
    </div>
  );
};

export default AnalysisResults;
