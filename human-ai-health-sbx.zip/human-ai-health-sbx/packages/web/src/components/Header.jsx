import { Heart } from 'lucide-react';

const Header = () => {
  return (
    <header className="header">
      <div className="header-content">
        <Heart size={32} className="header-icon" />
        <h1>Human AI Health Platform</h1>
      </div>
    </header>
  );
};

export default Header;
