import { useState } from 'react';
import DocumentUpload from './components/DocumentUpload';
import AnalysisResults from './components/AnalysisResults';
import DocumentHistory from './components/DocumentHistory';
import Header from './components/Header';
import './App.css';

function App() {
  const [analysisResults, setAnalysisResults] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [documentHistory, setDocumentHistory] = useState([]);
  const [activeDocumentId, setActiveDocumentId] = useState(null);

  const handleAnalysisComplete = (results, fileName) => {
    const newDocument = {
      id: Date.now().toString(),
      fileName,
      timestamp: new Date(),
      results,
      status: results.error ? 'error' : 'success',
    };

    setDocumentHistory((prev) => [newDocument, ...prev]);
    setAnalysisResults(results);
    setActiveDocumentId(newDocument.id);
    setIsLoading(false);
  };

  const handleAnalysisStart = () => {
    setIsLoading(true);
    setAnalysisResults(null);
    setActiveDocumentId(null);
  };

  const handleHistoryItemClick = (document) => {
    setAnalysisResults(document.results);
    setActiveDocumentId(document.id);
  };

  const handleClearHistory = () => {
    setDocumentHistory([]);
    setAnalysisResults(null);
    setActiveDocumentId(null);
  };

  return (
    <div className='app'>
      <Header />
      <main className='main-content'>
        <div className='container'>
          <div className='main-layout'>
            <div className='main-panel'>
              <DocumentUpload
                onAnalysisStart={handleAnalysisStart}
                onAnalysisComplete={handleAnalysisComplete}
                isLoading={isLoading}
              />
              {analysisResults && <AnalysisResults results={analysisResults} />}
            </div>
            <div className='sidebar-panel'>
              <DocumentHistory
                documents={documentHistory}
                activeDocumentId={activeDocumentId}
                onDocumentClick={handleHistoryItemClick}
                onClearHistory={handleClearHistory}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
