# Human AI Health Platform

A comprehensive monorepo solution for medical document analysis using React frontend and Python backend with Amazon Bedrock AI integration.

## 🏗️ Architecture

This monorepo contains:

- **Web Application** (`packages/web`): React frontend with document upload interface
- **API Service** (`packages/api`): Python FastAPI backend with Amazon Bedrock integration
- **Shared Configuration** (`config/`): Common JSON configuration for both services

## 🚀 Features

- **Document Upload**: Support for PDF, DOC, DOCX, TXT, and image files (JPG, PNG)
- **AI Analysis**: Amazon Bedrock integration for clinical risk assessment
- **Care Plan Suggestions**: AI-generated care plan recommendations
- **Responsive UI**: Modern React interface with drag-and-drop upload
- **Docker Support**: Full containerization for easy deployment
- **OCR Support**: Text extraction from images using Tesseract
- **Mock Mode**: Fallback analysis when Bedrock is not configured

## 📋 Prerequisites

- Node.js 18+ (for development)
- Python 3.11+ (for development)
- Docker and Docker Compose (for containerized deployment)
- AWS Account with Bedrock access (for AI features)

## 🛠️ Quick Start

### Option 1: Docker Deployment (Recommended)

1. **Clone and setup**:

   ```bash
   git clone <repository-url>
   cd human-ai-health-sbx
   ```

2. **Configure environment**:

   ```bash
   cp .env.example .env
   # Edit .env with your AWS credentials
   ```

3. **Start with Docker**:

   ```bash
   docker-compose up --build
   ```

4. **Access the application**:
   - Web App: http://localhost:3000
   - API: http://localhost:8000
   - API Docs: http://localhost:8000/docs

### Option 2: Development Setup

1. **Install root dependencies**:

   ```bash
   npm install
   ```

2. **Install web dependencies**:

   ```bash
   cd packages/web
   npm install
   cd ../..
   ```

3. **Install API dependencies**:

   ```bash
   cd packages/api
   pip install -r requirements.txt
   cd ../..
   ```

4. **Configure environment**:

   ```bash
   cp .env.example .env
   # Edit .env with your AWS credentials
   ```

5. **Start development servers**:
   ```bash
   npm run dev
   ```

## ⚙️ Configuration

### AWS Bedrock Setup

1. **Enable Bedrock Models**:

   - Go to AWS Bedrock console
   - Enable Claude 3 Sonnet model in your region
   - Note your AWS region

2. **AWS Credentials**:

   ```bash
   # Option 1: Environment variables
   export AWS_ACCESS_KEY_ID=your_access_key
   export AWS_SECRET_ACCESS_KEY=your_secret_key
   export AWS_DEFAULT_REGION=us-east-1

   # Option 2: AWS CLI
   aws configure

   # Option 3: IAM roles (for EC2/ECS deployment)
   ```

3. **Required IAM Permissions**:
   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Action": ["bedrock:InvokeModel"],
         "Resource": "arn:aws:bedrock:*:*:model/anthropic.claude-3-sonnet-20240229-v1:0"
       }
     ]
   }
   ```

### Application Configuration

Edit `config/app-config.json` to customize:

- **API Settings**: CORS origins, host, port
- **AWS Settings**: Region, Bedrock model configuration
- **Upload Settings**: File size limits, allowed extensions
- **Analysis Settings**: Risk categories, care plan areas

## 📁 Project Structure

```
human-ai-health-sbx/
├── packages/
│   ├── web/                 # React frontend
│   │   ├── src/
│   │   │   ├── components/  # React components
│   │   │   ├── App.jsx      # Main app component
│   │   │   └── main.jsx     # Entry point
│   │   ├── Dockerfile       # Web container
│   │   └── package.json
│   └── api/                 # Python backend
│       ├── services/        # Business logic
│       │   ├── bedrock_client.py
│       │   ├── document_processor.py
│       │   └── config_manager.py
│       ├── main.py          # FastAPI app
│       ├── Dockerfile       # API container
│       └── requirements.txt
├── config/
│   └── app-config.json      # Shared configuration
├── docker-compose.yml       # Container orchestration
├── package.json             # Root package file
└── README.md
```

## 🔧 Development

### Available Scripts

```bash
# Root level
npm run dev              # Start both web and API in development
npm run build           # Build web application
npm run docker:build   # Build Docker images
npm run docker:up      # Start Docker containers
npm run docker:down    # Stop Docker containers

# Web package
cd packages/web
npm run dev             # Start development server
npm run build           # Build for production
npm run preview         # Preview production build

# API package
cd packages/api
python main.py          # Start development server
uvicorn main:app --reload  # Alternative start command
```

### Adding New Features

1. **Frontend**: Add components in `packages/web/src/components/`
2. **Backend**: Add endpoints in `packages/api/main.py` or create new service modules
3. **Configuration**: Update `config/app-config.json` for new settings

## 🐳 Docker Deployment

### Production Deployment

1. **Build and start**:

   ```bash
   docker-compose -f docker-compose.yml up -d --build
   ```

2. **Environment variables**:

   ```bash
   # Create .env file with production values
   AWS_ACCESS_KEY_ID=your_production_key
   AWS_SECRET_ACCESS_KEY=your_production_secret
   AWS_DEFAULT_REGION=us-east-1
   ENVIRONMENT=production
   ```

3. **Health checks**:

   ```bash
   # Check API health
   curl http://localhost:8000/api/health

   # Check web application
   curl http://localhost:3000
   ```

### Scaling

For production scaling, consider:

- Load balancer for multiple web instances
- Multiple API instances behind a load balancer
- Shared storage for uploaded files
- Database for persistent data
- Redis for caching

## 🔒 Security Considerations

- **File Upload**: Validates file types and sizes
- **CORS**: Configured for specific origins
- **AWS Credentials**: Use IAM roles in production
- **Input Validation**: All inputs are validated
- **Error Handling**: Sensitive information is not exposed

## 🧪 Testing

### Manual Testing

1. **Upload a medical document** (PDF, DOC, or image)
2. **Click "Analyze with AI"**
3. **Review the results** showing clinical risks and care plan suggestions

### API Testing

```bash
# Health check
curl http://localhost:8000/api/health

# Upload and analyze (replace with actual file)
curl -X POST "http://localhost:8000/api/analyze-document" \
     -H "accept: application/json" \
     -H "Content-Type: multipart/form-data" \
     -F "file=@sample-prescription.pdf"
```

## 🐛 Troubleshooting

### Common Issues

1. **Bedrock Access Denied**:

   - Verify AWS credentials
   - Check IAM permissions
   - Ensure Bedrock model is enabled in your region

2. **File Upload Fails**:

   - Check file size (max 10MB)
   - Verify file type is supported
   - Ensure API is running

3. **OCR Not Working**:

   - Install Tesseract: `apt-get install tesseract-ocr`
   - For Docker: Already included in Dockerfile

4. **CORS Errors**:
   - Update `config/app-config.json` with correct origins
   - Restart API service

### Logs

```bash
# Docker logs
docker-compose logs web
docker-compose logs api

# Development logs
# API logs appear in terminal
# Web logs appear in browser console
```

## 📄 License

This project is licensed under the MIT License.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📞 Support

For support and questions:

- Create an issue in the repository
- Check the troubleshooting section
- Review the API documentation at `/docs` endpoint

## 🎯 Use Case

This platform is designed for nurses and healthcare professionals to:

1. **Upload Medical Documents**: Easily upload doctor prescriptions, medical notes, or patient records
2. **AI-Powered Analysis**: Get instant analysis of clinical risks and safety concerns
3. **Care Plan Generation**: Receive AI-generated care plan suggestions based on the document content
4. **Risk Assessment**: Identify potential medication interactions, allergies, and monitoring requirements
5. **Clinical Decision Support**: Use AI insights to enhance patient care and safety

The system provides a user-friendly interface for healthcare workers to leverage AI technology in their daily workflow, improving patient safety and care quality.
